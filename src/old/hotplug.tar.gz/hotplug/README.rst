=====
hotplug
=====

Simple library for handling hotpluging of devices.

.. contents:: Table of Contents:
   :local:

Requirements
============

- Boost
- libudev

On fedora libudev is part of the package `systemd-devel`
