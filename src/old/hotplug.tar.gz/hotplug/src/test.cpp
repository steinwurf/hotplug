// Copyright Steinwurf ApS 2016.
// Distributed under the "STEINWURF RESEARCH LICENSE 1.0".
// See accompanying file LICENSE.rst or
// http://www.steinwurf.com/licensing

#include <iostream>
#include <boost/asio.hpp>
#include <boost/bind.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>

#include "hotplug.hpp"

int main()
{
    boost::asio::io_service ioservice;

    //boost::asio::posix::stream_descriptor stream{ioservice, STDOUT_FILENO};
    boost::asio::posix::stream_descriptor stream = hotplug::get_stream_descriptor(ioservice);

    auto handler = [&stream](const boost::system::error_code&, std::size_t) {
//        stream.native_handle();
        std::cout << ", world!\n" << std::endl;
        std::cout << stream.native_handle() <<std::endl;
    };
    boost::asio::async_write(stream, boost::asio::buffer("Hello"), handler);
    boost::asio::async_read(stream, boost::asio::buffer("Hello"), handler);

    ioservice.run();
}
